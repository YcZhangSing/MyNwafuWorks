void main()
{
    int a,b,c,d,e;
    c = c-1;
    do
    {
        d = d+1;
		e = e+1;
    } while ((b+c)>a);
}