void main()
{
    int a,i,k,j,l;
    a = 2;
    switch(a)
   {
	 case 1:
        i=i+1;
        case 2:
        j=j+1;
        case 3:
        k=k+1;
	 default:
        l=l+1;
    }

}
