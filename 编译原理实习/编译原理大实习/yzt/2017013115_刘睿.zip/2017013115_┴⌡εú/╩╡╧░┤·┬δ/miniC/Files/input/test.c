void main()
{
    int a,b,c,d,e;
    while (e>0||(b+c)>a&&d<15)
    {
        d = 3;
		e = 4;
		while(d<15)
		{
		d = e+a;
		}
    }
} 