void main()
{
    int a,b,c,d,e;
	 
    for(a=0;a<1;a=a+1)
	{
		b=0;
		b=3;
	}
}