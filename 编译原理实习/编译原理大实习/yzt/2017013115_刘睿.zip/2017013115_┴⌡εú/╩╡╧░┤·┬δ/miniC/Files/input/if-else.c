void main()
{ 
	int a, b;
	a = 0;
	b = 10;
	if(a<b)
	{
		a = a+1;
	}
	else
	{
		b = 0;
	}
}