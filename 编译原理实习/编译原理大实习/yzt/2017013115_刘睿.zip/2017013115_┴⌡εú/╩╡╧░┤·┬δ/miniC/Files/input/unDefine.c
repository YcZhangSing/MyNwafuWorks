void main()
{
	int a;
	b=0;
}
