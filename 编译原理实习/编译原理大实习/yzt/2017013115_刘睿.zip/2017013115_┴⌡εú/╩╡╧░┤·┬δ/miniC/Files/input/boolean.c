void main(bool a, bool b)
{ 
	int c, d;
	c=0;
	d=1;
	if(a&&b||d<0&&!b)
	{
		a = a*b;
	}
}