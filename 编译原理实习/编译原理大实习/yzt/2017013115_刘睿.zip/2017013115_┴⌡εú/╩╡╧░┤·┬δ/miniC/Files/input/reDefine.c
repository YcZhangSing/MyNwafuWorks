void main()
{
   int a,b;
   int a;
}
