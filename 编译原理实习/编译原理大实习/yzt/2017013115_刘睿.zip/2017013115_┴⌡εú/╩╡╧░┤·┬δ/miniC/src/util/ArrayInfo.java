package util;

import java.util.ArrayList;

public class ArrayInfo {
	public int demenSize;
	public ArrayList<Integer> demenList;
	public int C;
}
