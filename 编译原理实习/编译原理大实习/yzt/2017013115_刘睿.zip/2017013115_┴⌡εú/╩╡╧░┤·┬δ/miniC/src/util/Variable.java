package util;

public class Variable {
	public String type;
	public String name;
	public int elementSize;
	public Variable(String name, String type, int elementSize)
	{
		this.name = name;
		this.type = type;
		this.elementSize = elementSize;
	}
}
 