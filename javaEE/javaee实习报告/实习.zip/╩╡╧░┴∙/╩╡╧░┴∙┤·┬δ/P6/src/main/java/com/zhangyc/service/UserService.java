package com.zhangyc.service;

public interface UserService {
    public String selectUserByName(String name);
}
